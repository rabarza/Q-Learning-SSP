import os
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))  # noqa: E402
from RLib.agents.ssp import QAgentSSP
from RLib.utils.dijkstra import get_q_table_for_path
from RLib.utils.plots import plot_results_per_episode_comp_plotly
from RLib.utils.files import load_model_results, find_files_by_keyword
from RLib.utils.serializers import QAgentSSPSerializer

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
RESULTS_DIR = os.path.join(BASE_DIR, "results")


number_of_layers = 18
number_of_nodes = 162
seed = 20
graph_name = f"Perceptron/{number_of_layers}Layers-{number_of_nodes}Nodes-Seed{seed}"
cost_distribution = "uniform" # "uniform"
is_dynamic = True
alpha_type = "dynamic" if is_dynamic else "constant"
ruta_carpeta = os.path.join(RESULTS_DIR, graph_name, cost_distribution, f"{alpha_type}_alpha/")

print(os.listdir(ruta_carpeta))
# Load QAgentSSP models
# e-greedy agents
greedy_files = find_files_by_keyword("e-", ruta_carpeta+"e-greedy")
greedy_agents = list(map(lambda x: load_model_results(
    x, ruta_carpeta+"e-greedy"), greedy_files))
# UCB1 agents
ucb_files = find_files_by_keyword("UCB1", ruta_carpeta+"UCB1")
ucb_agents = list(map(lambda x: load_model_results(
    x, ruta_carpeta+"UCB1"), ucb_files))
# exp3 agents
exp3_files = find_files_by_keyword("exp3", ruta_carpeta+"exp3")
exp3_agents = list(map(lambda x: load_model_results(
    x, ruta_carpeta+"exp3"), exp3_files))
try:
    asoptucb_files = find_files_by_keyword("AsOpt-UCB", ruta_carpeta+"AsOpt-UCB")
    asoptucb_agents = list(map(lambda x: load_model_results(
        x, ruta_carpeta+"AsOpt-UCB"), asoptucb_files))
except:
    asoptucb_agents = []

# criterias_list = ['error', 'policy error', 'score', 'steps', 'regret', 'average regret']
criterias_list = ['error', 'policy error', 'average regret']

for criteria in criterias_list:
    agents = greedy_agents + ucb_agents + exp3_agents + asoptucb_agents
    print(agents)
    fig = plot_results_per_episode_comp_plotly(agents, criteria)
    fig.show()

# if __name__ == "__main__":
#     from RLib.utils.serializers import serialize_table
#     import json

#     for agent in agents:
#         q_table = agent.q_table
#         path = agent.best_path()
#         q_table_for_sp = get_q_table_for_path(q_table, path)
#         serialized_q_table_for_sp = serialize_table(q_table_for_sp)
#         json_q_table_for_sp = json.dumps(serialized_q_table_for_sp, indent=4)
#         with open(os.path.join(RESULTS_DIR, f"q_star_for_shortest_path_{graph_name}_{orig_node}-{dest_node}_{agent.strategy}.json"), "w") as f:
#             f.write(json_q_table_for_sp)
#             f.close()
