import os
import sys
import networkx as nx
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))  # noqa: E402
from RLib.action_selectors import (
    EpsilonGreedyActionSelector,
    UCB1ActionSelector,
    AsOptUCBActionSelector,
    Exp3ActionSelector,
)
from RLib.utils.plots import plot_results_per_episode_comp_plotly
from RLib.utils.files import save_model_results, serialize_and_save_table
from RLib.utils.dijkstra import (
    get_optimal_policy,
    get_shortest_path_from_policy,
    get_q_table_for_policy,
    get_q_table_for_path,
)
from RLib.graphs.perceptron import create_perceptron_graph
from RLib.agents.ssp import QAgentSSP
from RLib.environments.ssp import SSPEnv

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
RESULTS_DIR = os.path.join(BASE_DIR, "results")

# Crear el grafo
# nodes_by_layer = [1, 2, 3, 2, 1]
# nodes_by_layer = [1, 30, 1] # 3 layers and 32 nodes
# nodes_by_layer = [1, 100, 1] # 3 layers and 102 nodes
# nodes_by_layer = [1, 200, 1] # 3 layers and 202 nodes
# nodes_by_layer = [1, 100, 10, 1] # 4 layers and 112 nodes
# nodes_by_layer = [1, 200, 20, 1] # 4 layers and 222 nodes
# nodes_by_layer = [1, 200, 40, 1] # 4 layers and 242 nodes
# nodes_by_layer = [1, 10, 10, 10, 10, 1] # 4 layers and 242 nodes
nodes_by_layer = [10] * 16
nodes_by_layer.insert(0, 1)
nodes_by_layer.append(1)
seed = 20
graph = create_perceptron_graph(nodes_by_layer, min_length=1, max_length=40, seed=seed) # noqa: E501
# Guardar la información del grafo en un archivo .json
graph_data = nx.node_link_data(graph)
graph_data['seed'] = seed
graph_data['nodes_by_layer'] = nodes_by_layer

# Definir el nodo de origen y el nodo objetivo
origin_node = ('Entrada', 0)
target_node = ('Salida', 0)
costs_distribution = "uniform" # "uniform"
graph_name = f"{len(nodes_by_layer)}Layers-{graph.number_of_nodes()}Nodes-Seed{seed}"
save_path = os.path.join(RESULTS_DIR, f"Perceptron/{graph_name}/{costs_distribution}/")  # noqa: E501
serialize_and_save_table(graph_data, os.path.join(RESULTS_DIR, f"Perceptron/{graph_name}"), f"graph_data_seed{seed}.json")  # noqa: E501
# Encontrar la política óptima, el camino más corto y la tabla Q*
policy = get_optimal_policy(graph, target_node, costs_distribution)
optimal_q_table = get_q_table_for_policy(graph, policy, target_node, costs_distribution, st=False)
shortest_path = get_shortest_path_from_policy(policy, origin_node, target_node)
optimal_q_table_for_sp = get_q_table_for_path(optimal_q_table, shortest_path)

# Guardar tablas en un archivo .json
serialize_and_save_table(optimal_q_table, save_path, f"optimal_q_table_distr_{costs_distribution}.json")  # noqa: E501
serialize_and_save_table(optimal_q_table_for_sp, save_path, f"optimal_q_table_for_sp_distr_{costs_distribution}.json")  # noqa: E501


# Crear el entorno SSP
environment = SSPEnv(graph, origin_node, target_node, costs_distribution, shortest_path)

# Instanciar los agentes
is_dynamic = True
formula = '1000 / (t + 1000)'
number_of_trials = 10
list_of_agents = []
c_values = [0.0001, 0.001, 0.01, 0.1, 0.2, 0.3, 0.5, 0.6, 0.7, 0.8, 0.9, 1, 2]
for i in range(len(c_values)):
    # Instanciar los selectores de acción
    eps_selector = EpsilonGreedyActionSelector(epsilon=0.1)
    ucb_selector = UCB1ActionSelector(c=c_values[i])
    aoucb_selector = AsOptUCBActionSelector()
    exp3Sqrt_selector = Exp3ActionSelector(eta='sqrt(t)')
    exp3Log_selector = Exp3ActionSelector(eta='log(t+1)')
    uniform_selector = EpsilonGreedyActionSelector(epsilon=1)
    # Instanciar los agentes 
    agent1 = QAgentSSP(environment=environment, dynamic_alpha=is_dynamic, alpha_formula=formula, action_selector=eps_selector)
    agent2 = QAgentSSP(environment=environment, dynamic_alpha=is_dynamic, alpha_formula=formula, action_selector=ucb_selector)
    agent3 = QAgentSSP(environment=environment, dynamic_alpha=is_dynamic, alpha_formula=formula, action_selector=uniform_selector)
    agent4 = QAgentSSP(environment=environment, dynamic_alpha=is_dynamic, alpha_formula=formula, action_selector=exp3Sqrt_selector)
    agent5 = QAgentSSP(environment=environment, dynamic_alpha=is_dynamic, alpha_formula=formula, action_selector=exp3Log_selector)
    agent6 = QAgentSSP(environment=environment, dynamic_alpha=is_dynamic, alpha_formula=formula, action_selector=aoucb_selector)
    
    # Realizar entrenamientos
    num_episodes = 10000
    agent1.train(num_episodes, shortest_path=shortest_path, q_star=optimal_q_table)
    agent1.save(save_path)
    agent2.train(num_episodes, shortest_path=shortest_path, q_star=optimal_q_table)
    agent2.save(save_path)
    agent3.train(num_episodes, shortest_path=shortest_path, q_star=optimal_q_table)
    agent3.save(save_path)
    agent4.train(num_episodes, shortest_path=shortest_path, q_star=optimal_q_table)
    agent4.save(save_path)
    agent5.train(num_episodes, shortest_path=shortest_path, q_star=optimal_q_table)
    agent5.save(save_path)
    agent6.train(num_episodes, shortest_path=shortest_path, q_star=optimal_q_table)
    agent6.save(save_path)

# plot_results_per_episode_comp_plotly(list_of_agents, criteria='error').show()
# plot_results_per_episode_comp_plotly(list_of_agents, criteria='policy error').show()
# plot_results_per_episode_comp_plotly(list_of_agents, criteria='steps').show()
# plot_results_per_episode_comp_plotly(list_of_agents, criteria='regret').show()
# plot_results_per_episode_comp_plotly(list_of_agents, criteria='average regret').show()