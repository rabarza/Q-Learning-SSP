import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))  # noqa: E402
from RLib.action_selectors import (
    EpsilonGreedyActionSelector,
    UCB1ActionSelector,
    Exp3ActionSelector,
)
from RLib.utils.files import save_model_results, serialize_and_save_table
from RLib.utils.dijkstra import (
    get_optimal_policy,
    get_shortest_path_from_policy,
    get_q_table_for_policy,
    get_q_table_for_path,
)
from RLib.agents.ssp import QAgentSSP
from RLib.environments.ssp import HardSSPEnv
import numpy as np
import osmnx as ox
import winsound  # Para hacer sonar un beep al finalizar el entrenamiento

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
RESULTS_DIR = os.path.join(BASE_DIR, "results")

location_name = "Santiago, Chile"
origin_node = 1881661577
target_node = 265665010
costs_distribution = "uniform"  # "lognormal"

# Definir la ruta para guardar los resultados
save_path = os.path.join(RESULTS_DIR, f"Hard{location_name}/{origin_node}-{target_node}/{costs_distribution}/")  # noqa: E501

# Descargar el grafo y preprocesarlo
print(f"Downloading graph for {location_name}...")
graph = ox.graph_from_place(location_name, network_type="drive")
print("Graph downloaded successfully!")
# Preprocesamiento del grafo
graph = ox.add_edge_speeds(graph)  # Añadir velocidad a los arcos (speed_kph)
# Quita los arcos con largo demasiado corto
min_length = 3
# Filtrar los bordes que cumplen con el criterio de longitud mínima
edges_to_remove = [(u, v) for u, v, data in graph.edges(data=True) if data.get('length', 0) < min_length]  # noqa: E501
graph.remove_edges_from(edges_to_remove)
# Obtener el componente fuertemente conexo más grande
graph = ox.truncate.largest_component(graph, strongly=True)

# Añadir un arco recurrente de largo 0 en el nodo terminal
outgoing_edges = list(graph.out_edges(target_node))  # arcos salientes del nodo
if outgoing_edges:
    graph.remove_edges_from(outgoing_edges)
graph.add_edge(target_node, target_node, length=0, speed_kph=30)

print("Calculating shortest path...")
# Encontrar la política óptima, el camino más corto y la tabla Q*
optimal_policy = get_optimal_policy(graph, target_node, costs_distribution)
optimal_q_table = get_q_table_for_policy(graph, optimal_policy, target_node, costs_distribution)  # noqa: E501
shortest_path = get_shortest_path_from_policy(optimal_policy, origin_node, target_node)  # noqa: E501
print("Shortest path calculated successfully!")
# Obtener la tabla Q* para los nodos del camino más corto
optimal_q_table_for_sp = get_q_table_for_path(optimal_q_table, shortest_path)
# Guardar tablas en un archivo .json
serialize_and_save_table(optimal_q_table, save_path, f"optimal_q_table_distr_{costs_distribution}.json")  # noqa: E501
serialize_and_save_table(optimal_q_table_for_sp, save_path, f"optimal_q_table_for_sp_distr_{costs_distribution}.json")  # noqa: E501

# Crear el entorno de entrenamiento
NUM_EPISODES = 50000
environment = HardSSPEnv(graph, origin_node, target_node,
                     costs_distribution, shortest_path)

# Entrenar agentes con diferentes estrategias
agents = []
is_dynamic_alpha = True
alpha_type = "dynamic" if is_dynamic_alpha else "constant"
# c_values = np.linspace(0.0001, 0.5, 15)
c_values = [0.0001, 0.001, 0.01, 0.1, 0.2, 0.3, 0.5, 0.6, 0.7, 0.8, 0.9, 1, 2]

selectors = {
    "e-greedy": EpsilonGreedyActionSelector(epsilon=0.1),
    "UCB1": UCB1ActionSelector,
    "exp3": Exp3ActionSelector(eta="sqrt(t)"),
}
for c in c_values:
    for strategy, selector_class in selectors.items():
        selector = selector_class(
            c=c) if strategy == "UCB1" else selector_class

        # Crear y entrenar el agente
        agent = QAgentSSP(
            environment,
            dynamic_alpha=is_dynamic_alpha,
            alpha_formula="250 / (t + 250)",
            action_selector=selector
        )
        print(
            f"Training agent with strategy: {strategy} and cost distribution: {environment.costs_distribution}")
        agent.train(NUM_EPISODES, shortest_path=shortest_path,
                    q_star=optimal_q_table)
        agents.append(agent)

        results_dir = os.path.join(
            save_path, f"{alpha_type}_alpha/{strategy}/")
        os.makedirs(results_dir, exist_ok=True)
        save_model_results(agent, results_path=results_dir)

# winsound.Beep(2000, 4000)  # Beep con frecuencia de 1000 Hz durante 2 segundos
