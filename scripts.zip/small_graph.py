import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))  # noqa: E402
from RLib.utils.files import save_model_results, serialize_and_save_table
from RLib.utils.dijkstra import (
    get_optimal_policy,
    get_shortest_path_from_policy,
    get_q_table_for_policy,
    get_q_table_for_path,
)
from RLib.agents.ssp import QAgentSSP
from RLib.environments.ssp import SSPEnv
from RLib.utils.plots import plot_results_per_episode_comp_plotly
import numpy as np
import json
from RLib.action_selectors import (
    EpsilonGreedyActionSelector,
    UCB1ActionSelector,
    Exp3ActionSelector,
    AsOptUCBActionSelector,
)
import networkx as nx


# Definir la ubicación de los resultados
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
RESULTS_DIR = os.path.join(BASE_DIR, "results")
GRAPH_NAME = "small_graph"

# Nodos de origen y destino
orig_node = 0
dest_node = 4
distribution = "uniform"  # "lognormal"

# Definir la ruta para guardar los resultados
save_path = os.path.join(RESULTS_DIR, f"{GRAPH_NAME}/{orig_node}-{dest_node}/{distribution}/")  # noqa: E501

# Crear un grafo simple
G = nx.DiGraph()
G.add_node(0)
G.add_node(1)
G.add_node(2)
G.add_node(3)
G.add_node(4)
G.add_edge(0, 1, length=100, speed_kph=50)
G.add_edge(1, 2, length=150, speed_kph=60)
G.add_edge(2, 4, length=200, speed_kph=40)
G.add_edge(0, 3, length=200, speed_kph=40)
G.add_edge(3, 2, length=150, speed_kph=50)
G.add_edge(3, 4, length=100, speed_kph=50)
# G.add_edge(4, 2, length=100, speed_kph=50)




# Calcular la política óptima y la tabla Q^*
policy = get_optimal_policy(G, dest_node, distribution=distribution)
optimal_q_table = get_q_table_for_policy(
    G, policy, dest_node, distribution=distribution)
shortest_path = shortest_path = get_shortest_path_from_policy(
    policy, orig_node, dest_node
)
optimal_q_table_for_sp = get_q_table_for_path(optimal_q_table, shortest_path)

# Guardar tablas en un archivo .json
serialize_and_save_table(optimal_q_table, save_path, f"optimal_q_table_distr_{distribution}.json")  # noqa: E501
serialize_and_save_table(optimal_q_table_for_sp, save_path, f"optimal_q_table_for_sp_distr_{distribution}.json")  # noqa: E501


# Configuración del entorno y del agente
alpha = "10 / (t + 10)"
env = SSPEnv(G, orig_node, dest_node, distribution, shortest_path)
agent = QAgentSSP(env, alpha_formula=alpha,
                  action_selector=EpsilonGreedyActionSelector(epsilon=0.1))
agent_ucb = QAgentSSP(env, alpha_formula=alpha,
                      action_selector=UCB1ActionSelector(c=.0001))
agent_ao_ucb = QAgentSSP(env, alpha_formula=alpha,
                         action_selector=AsOptUCBActionSelector())
agent_exp3 = QAgentSSP(env, alpha_formula=alpha,
                       action_selector=Exp3ActionSelector(eta="sqrt(t)"))
agent_exp3_2 = QAgentSSP(env, alpha_formula=alpha,
                         action_selector=Exp3ActionSelector(eta="log(t+1)"))
NUM_EPISODES = 10000

# Entrenamiento del agente
agent.train(NUM_EPISODES, shortest_path=shortest_path, q_star=optimal_q_table)
agent_ucb.train(NUM_EPISODES, shortest_path=shortest_path,
                q_star=optimal_q_table)
# agent_ao_ucb.train(NUM_EPISODES, shortest_path=shortest_path, q_star=optimal_q_table)
agent_exp3.train(NUM_EPISODES, shortest_path=shortest_path,
                 q_star=optimal_q_table)
agent_exp3_2.train(NUM_EPISODES, shortest_path=shortest_path,
                   q_star=optimal_q_table)

list_agents = [agent, agent_ucb, agent_exp3, agent_exp3_2]
print("Camino más corto:", shortest_path)
print("Tabla Q^* esperada:", optimal_q_table)
print("Tabla Q aprendida por el agente:", agent.q_table)
print("Política óptima:", policy)

plot_results_per_episode_comp_plotly(list_agents, "error").show()
plot_results_per_episode_comp_plotly(list_agents, "policy error").show()
plot_results_per_episode_comp_plotly(list_agents, "average regret").show()
plot_results_per_episode_comp_plotly(list_agents, "optimal paths").show()
plot_results_per_episode_comp_plotly(list_agents, "score").show()
plot_results_per_episode_comp_plotly(list_agents, "steps").show()

for agent in list_agents:
    results_dir = os.path.join(save_path, f"dynamic_alpha/{agent.strategy}/")
    # Guardar resultados
    save_model_results(
        agent, results_path=results_dir
    )
