import os
import sys
import networkx as nx
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))  # noqa: E402
from RLib.action_selectors import (
    EpsilonGreedyActionSelector,
    UCB1ActionSelector,
    AsOptUCBActionSelector,
    Exp3ActionSelector,
)
from RLib.utils.plots import plot_results_per_episode_comp_plotly
from RLib.utils.files import save_model_results, serialize_and_save_table
from RLib.utils.dijkstra import (
    dijkstra_shortest_path,
    get_optimal_policy,
    get_shortest_path_from_policy,
    get_q_table_for_policy,
    get_q_table_for_path,
)
from RLib.graphs.perceptron import create_hard_perceptron_graph, plot_network_graph
from RLib.agents.ssp import QAgentSSP, QAgentSSPExp3, QAgentSSPBanditExp3, QAgentSSPStepRewardExp3, QAgentSSPBanditQ2Exp3
from RLib.environments.ssp import HardSSPEnv

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
RESULTS_DIR = os.path.join(BASE_DIR, "results")

# Crear el grafo
nodes_by_layer = [10] * 42
nodes_by_layer.insert(0, 1)
nodes_by_layer.append(1)
seed = 20
# Guardar la información del grafo en un archivo .json
costs_distribution = "uniform"
graph = create_hard_perceptron_graph(nodes_by_layer, min_length=20, max_length=60, seed=seed, costs_distribution=costs_distribution)  # noqa: E501
graph_data = nx.node_link_data(graph)
graph_data['seed'] = seed
graph_data['nodes_by_layer'] = nodes_by_layer
plot_network_graph(graph, False)
# Definir el nodo de origen y el nodo objetivo
origin_node = ('Entrada', 0)
target_node = ('Salida', 0)
graph_name = f"{len(nodes_by_layer)}Layers-{graph.number_of_nodes()}Nodes-Seed{seed}"
save_path = os.path.join(RESULTS_DIR, f"HardPerceptron/{graph_name}/{costs_distribution}/")  # noqa: E501
serialize_and_save_table(graph_data, os.path.join(RESULTS_DIR, f"HardPerceptron/{graph_name}"), f"graph_data_seed{seed}.json")  # noqa: E501

# Encontrar la política óptima, el camino más corto y la tabla Q*
policy = get_optimal_policy(graph, target_node, costs_distribution)
# quitar todos los arocs desde los nodos no optimos hacia los nodos del camino más corto

optimal_q_table = get_q_table_for_policy(graph, policy, target_node, costs_distribution, st=False)  # noqa: E501
shortest_path = get_shortest_path_from_policy(policy, origin_node, target_node)
optimal_q_table_for_sp = get_q_table_for_path(optimal_q_table, shortest_path)

# Guardar tablas en un archivo .json
serialize_and_save_table(optimal_q_table, save_path, f"optimal_q_table_distr_{costs_distribution}.json")  # noqa: E501
serialize_and_save_table(optimal_q_table_for_sp, save_path, f"optimal_q_table_for_sp_distr_{costs_distribution}.json")  # noqa: E501

# Crear el entorno SSP
environment = HardSSPEnv(graph, origin_node, target_node,
                         costs_distribution, shortest_path)

# Instanciar los agentes
is_dynamic = True
formula = '1000 / (t + 1000)'
number_of_trials = 5
list_of_agents = []
c_values = [0.0001, 0.001, 0.01, 0.1, 0.2, 0.3, 0.5, 0.6, 0.7, 0.8, 0.9, 1, 2, 3, 4, 5]
# eta_values = ['sqrt(t)', 'log(t+1)', '0.1', 'sqrt(log( A ) / T * A )', ]
for trial in range(number_of_trials):
    for i in range(len(c_values)):
        # Instanciar los selectores de acción
        eps_selector = EpsilonGreedyActionSelector(epsilon=0.1)
        ucb_selector = UCB1ActionSelector(c=c_values[i])
        # aoucb_selector = AsOptUCBActionSelector()
        # exp3Sqrt_selector = Exp3ActionSelector(eta='sqrt(t)')
        # exp3Log_selector = Exp3ActionSelector(eta='log(t+1)')
        # exp3_selector = Exp3ActionSelector(eta=eta_values[i])
        # uniform_selector = EpsilonGreedyActionSelector(epsilon=1)
        # Instanciar los agentes
        agent1 = QAgentSSP(environment=environment, dynamic_alpha=is_dynamic, alpha_formula=formula, action_selector=eps_selector)
        agent2 = QAgentSSP(environment=environment, dynamic_alpha=is_dynamic, alpha_formula=formula, action_selector=ucb_selector)
        # agent3 = QAgentSSP(environment=environment, dynamic_alpha=is_dynamic, alpha_formula=formula, action_selector=uniform_selector)
        # agent4 = QAgentSSP(environment=environment, dynamic_alpha=is_dynamic, alpha_formula=formula, action_selector=exp3Sqrt_selector)
        # agent5 = QAgentSSP(environment=environment, dynamic_alpha=is_dynamic, alpha_formula=formula, action_selector=exp3_selector)
        # agent6 = QAgentSSP(environment=environment, dynamic_alpha=is_dynamic, alpha_formula=formula, action_selector=aoucb_selector)
        # eta = 'sqrt(log( A ) / T * A )'
        # agent7 = QAgentSSPExp3(environment=environment, dynamic_alpha=is_dynamic, alpha_formula=formula, eta=eta_values[i])
        # agent8 = QAgentSSPBanditExp3(environment=environment, dynamic_alpha=is_dynamic, alpha_formula=formula, eta=eta_values[i])
        # agent9 = QAgentSSPStepRewardExp3(environment=environment, dynamic_alpha=is_dynamic, alpha_formula=formula, eta=eta_values[i])
        # agent10 = QAgentSSPBanditQ2Exp3(environment=environment, dynamic_alpha=is_dynamic, alpha_formula=formula, eta=eta_values[i])
        # Realizar entrenamientos
        num_episodes = 20000
        agent1.train(num_episodes, shortest_path=shortest_path, q_star=optimal_q_table)
        agent1.save(save_path)
        agent2.train(num_episodes, shortest_path=shortest_path, q_star=optimal_q_table)
        agent2.save(save_path)
        # agent3.train(num_episodes, shortest_path=shortest_path, q_star=optimal_q_table)
        # agent3.save(save_path)
        # agent4.train(num_episodes, shortest_path=shortest_path, q_star=optimal_q_table)
        # agent4.save(save_path)
        # agent5.train(num_episodes, shortest_path=shortest_path, q_star=optimal_q_table)
        # agent5.save(save_path)
        # agent6.train(num_episodes, shortest_path=shortest_path, q_star=optimal_q_table)
        # agent6.save(save_path)
        # agent10.train(num_episodes, shortest_path=shortest_path, q_star=optimal_q_table)
        # agent10.save(save_path)
        # agent7.train(num_episodes, shortest_path=shortest_path, q_star=optimal_q_table)
        # agent7.save(save_path)
        # agent8.train(num_episodes, shortest_path=shortest_path, q_star=optimal_q_table)
        # agent8.save(save_path)
        # agent9.train(num_episodes, shortest_path=shortest_path, q_star=optimal_q_table)
        # agent9.save(save_path)

    # plot_results_per_episode_comp_plotly(list_of_agents, criteria='error').show()
    # plot_results_per_episode_comp_plotly(list_of_agents, criteria='policy error').show()
    # plot_results_per_episode_comp_plotly(list_of_agents, criteria='steps').show()
    # plot_results_per_episode_comp_plotly(list_of_agents, criteria='reward').show()
    # plot_results_per_episode_comp_plotly(list_of_agents, criteria='average reward').show()
    # plot_results_per_episode_comp_plotly(list_of_agents, criteria='regret').show()
    # plot_results_per_episode_comp_plotly(list_of_agents, criteria='average regret').show()
